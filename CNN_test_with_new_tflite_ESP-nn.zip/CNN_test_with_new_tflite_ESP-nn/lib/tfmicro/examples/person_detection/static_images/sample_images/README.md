# About Images

  - The images embedded here are 96x96 greyscale images.
  - These can be viewed at https://rawpixels.net

## Image descriptions:

  - image0: A person
  - image1: A dog
  - image2: A person
  - image3: A Monkey
  - image4: A person
  - image5: A cat
  - image6: A person (not in focus)
  - image7: Portrait of a person
  - image8: A person
  - image9: A person
