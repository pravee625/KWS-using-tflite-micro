#ifndef __converted_model_h__
#define __converted_model_h__

extern unsigned char converted_model_tflite[];
extern unsigned int converted_model_tflite_len;

#endif